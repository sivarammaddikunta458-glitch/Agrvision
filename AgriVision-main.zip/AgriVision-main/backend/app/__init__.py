"""AgriVision Backend Package"""
__version__ = "1.0.0"
